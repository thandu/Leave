<?php /* Template Name: CustomPageT2 */ ?>
<?php

If($_POST['Submit']) {
// run validation if you're not doing it in js
global $wpdb;

$coursename=$_POST['coursename'];
$coursename1=$_POST['coursevalue'];
$coursecategory=$_POST['coursecategory'];

if($wpdb->insert(
        'custom',
        array(
                'name' => $coursename,
                'email' => $coursename1,
                'message' =>$coursecategory
            )
) == false) wp_die('Database Insertion failed'); else echo 'Database insertion successful<p />';

?>
<a href="" onClick="return false;" id="addform">Add Another Course.</a>
<?php
}
else // else we didn't submit the form, so display the form
{
?><form action="" method="post" id="addcourse">

<label id="coursename">Course Name:<input type="text" name="coursename" size="30" /></label>
<label id="coursevalue">Points Value:<input type="text" name="coursevalue" size="10"  /></label>

<label id="coursecategory">Course Category:<select name="coursecategory" size="1">
        <option selected>Product Knowledge</option>
        <option>Demonstrate Effectively</option>
        <option>Perfect Your Pitch</option>
        <option>Business Integration and Technical Training</option>
    </select></label>

<p> </p>
<p> </p>
</div>
<input type="submit" name="Submit" id="addcoursesubmit" value="Submit" />
</form>
<a href="" onClick="return false;" id="addform">Add Another Course.</a>
<?php
} // end else no post['submit']
?>
