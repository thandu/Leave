<?php 
/** 
* Template Name: Sign In
*/ 
get_header(); 

        global $wpdb;
		$username = $_POST["username"];
		$password = $_POST["password"];
 
	 	 
	 $sql = "SELECT username FROM mytable WHERE username = '$username'";
	echo $results = $wpdb->get_results($sql) or die($wpdb->show_errors());
	

    foreach( $results as $result ) {

        echo $result->username;

    }
        
?> 

<form id="wp_login_form" action="" method="post"> 
<label for="tab-1" class="tab">Sign In</label><br>

<label class="my-username" >Username</label><br> 
<input type="text" name="username" class="text" value=""><br> 
<label class="my-password" >Password</label><br>

<input type="password" name="password" class="text" value=""> <br> 
<label> 
<input class="myremember" name="rememberme" type="checkbox" value="forever"><span class="hey">Remember me</span></label> 
<br><br> 
<input type="submit" id="submitbtn" name="submit" value="Login"> 

</form>
<?php get_footer(); ?>