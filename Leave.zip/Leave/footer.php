<footer class="site-footer">
    <p><?php bloginfo( 'name' ) ?></p>
</footer>
 </div> <!-- closes <div class=container"> -->
<?php wp_footer() ?>
</body>
</html>